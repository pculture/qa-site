import shutil
import os
import sys

# add XULRunner DLLs to the path
path = os.environ['PATH'].split(";")
path.append(os.path.abspath("xulrunner-sdk\\bin"))
os.environ['PATH'] = ';'.join(path)

if os.path.exists("build"):
    shutil.rmtree("build")

# Build the extension modules and add them to the python path
sys.argv = ["setup.py", "build"] # trick distutils
import setup
setup.do_setup()
sys.path.append("build\\lib.win32-2.5")

print "-" * 40
print "RUNNING"
print "-" * 40
import xulrunnerbrowser
import gobject
import gtk
import threading

class BrowserWidget1(gtk.DrawingArea):
    # Initial try.  Create a DrawingArea widget and use that widget's window.
    # This seems like the most straightforward way.
    def __init__(self):
        gtk.DrawingArea.__init__(self)
        self.browser = None
        self.connect('realize', self.on_realize)
        self.connect('size-allocate', self.on_size_allocate)
        self.connect('button-press-event', self.on_button_press)
        self.connect('focus-in-event', self.on_focus_in)
        self.connect('focus-out-event', self.on_focus_out)
        self.set_property('can-focus', True)

    def on_realize(self, widget):
        print 'realize'
        self.browser = xulrunnerbrowser.XULRunnerBrowser(widget.window.handle, 
                0, 0, widget.allocation.width, widget.allocation.height)
        self.browser.load_uri("http://www.google.com/")

    def on_button_press(self, widget, event):
        # I'd like to give xulrunner focus here, but this event never fires
        print 'button-press'

    def on_focus_in(self, widget, event):
        print 'focus'
        self.browser.set_focus(True)

    def on_focus_out(self, widget, event):
        print 'focus out'
        self.browser.set_focus(False)

    def on_size_allocate(self, widget, rect):
        if self.browser:
            self.browser.reposition(0, 0, rect.width, rect.height)

class BrowserWidget2(gtk.EventBox):
    # Second Try.  Create the browser window as a child of the main widget.  I
    # used an EventBox, since it's the simplest container widget that holds
    # one child.  This one is closer to the gtkmozembed model.
    def __init__(self):
        gtk.EventBox.__init__(self)
        self.add(gtk.DrawingArea())
        self.child.show()
        self.browser = None
        self.set_property('can-focus', True)
        self.connect('button-press-event', self.on_button_press)
        self.connect('size-allocate', self.on_size_allocate)
        self.connect('focus-in-event', self.on_focus_in)
        self.connect('focus-out-event', self.on_focus_out)
        self.child.connect('realize', self.on_child_realize)
        self.child.connect('size-allocate', self.on_child_size_allocate)

    def on_button_press(self, widget, event):
        # I'd like to give xulrunner focus here, but this event never fires
        print 'button-press'

    def on_focus_in(self, widget, event):
        print 'focus'
        self.browser.set_focus(True)

    def on_focus_out(self, widget, event):
        print 'focus out'
        self.browser.set_focus(False)

    def on_size_allocate(self, widget, rect):
        # Give the child all of our space
        child_rect = gtk.gdk.Rectangle(0, 0, rect.width, rect.height)
        self.child.size_allocate(child_rect)

    def on_child_realize(self, widget):
        self.browser = xulrunnerbrowser.XULRunnerBrowser(widget.window.handle, 
                0, 0, widget.allocation.width, widget.allocation.height)
        self.browser.load_uri("http://www.google.com/")

    def on_child_size_allocate(self, widget, rect):
        if self.browser:
            self.browser.reposition(rect.x, rect.y, rect.width, rect.height)

# Pick which implementation you want to try out
BrowserWidget = BrowserWidget1 
#BrowserWidget = BrowserWidget2

# Initailize XULRunner...  I didn't use the XPCOM glue strategy, because I
# figure that we control the xulrunner we're going to ship with Miro and we
# will always know where xul.dll is located.
xul_dir = os.path.join(os.getcwd(), 'xulrunner-sdk', 'bin')
app_dir = os.getcwd()
xulrunnerbrowser.initialize(xul_dir, app_dir)
# Start the GTK side of things
window = gtk.Window()
window.set_size_request(500, 500)
window.set_title("Test XULRunner Embedding")
window.connect('destroy', gtk.main_quit)
# Make a vbox to pack things into
vbox = gtk.VBox()
window.add(vbox)
# Create a text entry to test focus
vbox.pack_start(gtk.Entry(), expand=False)
# Create a label to make the layout a little more interesting
vbox.pack_start(gtk.Label("HELLO"), expand=False)
# Create the browser widget.
vbox.pack_start(BrowserWidget(), expand=True)
window.show_all()
gtk.main()
