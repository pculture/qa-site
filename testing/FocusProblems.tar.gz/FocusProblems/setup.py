from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext


xulbrowser_mod = Extension("xulrunnerbrowser",
        include_dirs=[
            'xulrunner-sdk\\include\\docshell',
            'xulrunner-sdk\\include\\widget',
            'xulrunner-sdk\\include\\xulapp',
            'xulrunner-sdk\\\\sdk\\include',

            'xulrunner-sdk\\include\\dom',
            'xulrunner-sdk\\include\\content',
            ],
        define_macros=[("XP_WIN", 1)],
        library_dirs=["xulrunner-sdk\\lib"],
        libraries=[
            'embed_base_s',
            'xpcom',
            'xpcomglue_s',
            'nspr4',
            'xul',
            'user32',
        ],
        language="c++",
        sources=
            ['xulrunnerbrowser.pyx', 
            'XULRunnerBrowserXPCOM.cpp', 
            'webbrowserchrome.cpp'])

def do_setup():
    setup(
        name="test",
        version="1.0",
        ext_modules = [xulbrowser_mod],
        cmdclass = { 'build_ext': build_ext },
    )
